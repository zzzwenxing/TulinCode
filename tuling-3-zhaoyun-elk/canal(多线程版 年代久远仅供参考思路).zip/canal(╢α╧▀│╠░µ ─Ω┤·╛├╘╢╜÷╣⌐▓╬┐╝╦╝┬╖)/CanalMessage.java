package com.cccc.searchcenter.manager.canal;

import com.alibaba.otter.canal.protocol.CanalEntry.EventType;

/**
 * Description: TODO <br/>
 * 
 * @author: zhaoyun
 * @date: 2015年5月6日 上午11:03:32
 * @version: 1.0
 * @since: JDK 1.7
 */
public class CanalMessage {
    private EventType eventType;
    private String schameName;
    private String tableName;
    private String id;

    public EventType getEventType() {
        return eventType;
    }

    public void setEventType(EventType eventType) {
        this.eventType = eventType;
    }

    public String getSchameName() {
        return schameName;
    }

    public void setSchameName(String schameName) {
        this.schameName = schameName;
    }

    public String getTableName() {
        return tableName;
    }

    public void setTableName(String tableName) {
        this.tableName = tableName;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCanalFilterName() {
        return this.schameName + "&" + this.tableName;
    }

    @Override
    public String toString() {
        return "CanalMessage [eventType=" + eventType + ", schameName=" + schameName + ", tableName=" + tableName + ", id=" + id
                + "]";
    }

}
