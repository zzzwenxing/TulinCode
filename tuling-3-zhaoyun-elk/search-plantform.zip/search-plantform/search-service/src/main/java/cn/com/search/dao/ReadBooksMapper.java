package cn.com.search.dao;

import cn.com.search.core.Mapper;
import cn.com.search.model.ReadBooks;

public interface ReadBooksMapper extends Mapper<ReadBooks> {
}