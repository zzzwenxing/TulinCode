package com.cccc.searchcenter.manager.server;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang.StringUtils;
import org.apache.solr.common.SolrInputDocument;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.cccc.searchcenter.core.solr.SolrIndexService;
import com.cccc.searchcenter.manager.canal.CanalMessage;
import com.cccc.searchcenter.manager.canal.CanalTool;
import com.cccc.searchcenter.manager.dataImport.DataSourceManage;
import com.cccc.searchcenter.manager.dataImport.conf.ConfigManager;
import com.cccc.searchcenter.manager.dataImport.conf.DIConfig;

/**
 * Description: TODO <br/>
 * 
 * @author: zhaoyun
 * @date: 2015年4月28日 下午5:31:09
 * @version: 1.0
 * @since: JDK 1.7
 */
@Service
public class IncServer {
    private static final Logger logger = LoggerFactory.getLogger(IncServer.class);
    @Autowired
    ConfigManager configManager;
    @Autowired
    DataSourceManage dataSourceManager;
    @Autowired
    CanalTool canalTool;
    @Autowired
    SolrIndexService solrIndexService;
    ExecutorService indexExe = Executors.newFixedThreadPool(10);
    Map<String, String> solrCollNameMap = new HashMap<>();
    @Value("${canal.primaryKey.name}")
    private String toPrimaryKeyName;
    @Value("${canal.solrcollection.name}")
    private String toCollectionName;
    @Value("${canal.filter}")
    private String canalFilterStr;
    @Value("${solr.collNames}")
    private String collNames;

    public void init() {
        List<DIConfig> config = configManager.loadConfig();
        dataSourceManager.init(config);
        // 启动增量
        incStartUp();
        logger.info("增量启动完成");
    }

    public void incStartUp() {
        // load multi instances
        // ---------------------------------------------------------------------------------------
        // 这一块要配置到配置文件中
        // 用于获取对应的id（不一定是主键）
        Map<String, String> tableIdNameMap = new HashMap<>();
  
        if (StringUtils.isNotBlank(toPrimaryKeyName)) {
            String[] L1 = toPrimaryKeyName.split(";");
            for (int i = 0; i < L1.length; i++) {
                String[] L2 = L1[i].split("\\|");
                if (L2.length == 2) {
                    tableIdNameMap.put(L2[0], L2[1]);
                    logger.info("loading[primary key name]:" + L2[0] + ":" + L2[1]);
                }
            }
        }
        canalTool.setTableIdNameMap(tableIdNameMap);
        // ---------------------------------------------------------------------------------------
       
        if (StringUtils.isNotBlank(toCollectionName)) {
            String[] L1 = toCollectionName.split(";");
            for (int i = 0; i < L1.length; i++) {
                String[] L2 = L1[i].split("\\|");
                if (L2.length == 2) {
                    solrCollNameMap.put(L2[0], L2[1]);
                    logger.info("loading[collection name]:" + L2[0] + ":" + L2[1]);
                }
            }
        }
        // ---------------------------------------------------------------------------------------
        //
        // canalTool.load("goods", "bbg_plat_goods.gc_brand");
        if (StringUtils.isNotBlank(canalFilterStr)) {
            String[] L1 = canalFilterStr.split(";");
            for (int i = 0; i < L1.length; i++) {
                String[] L2 = L1[i].split("\\|");
                if (L2.length == 2) {
                    canalTool.load(L2[0], L2[1]);
                    logger.info("loading[canal filter]:" + L2[0] + ":" + L2[1]);
                }
            }
        }

        // commit
        if (StringUtils.isNotBlank(collNames)) {
            String[] coll = collNames.split(",");
            for (int i = 0; i < coll.length; i++) {
                Thread commitThread = new Thread(new CommitThread(solrIndexService, coll[i]), "commit_" + i);
                commitThread.start();
                logger.info("commit thread started ... " + coll[i]);
            }
        }
        // indexExeSubmit
        Thread indexExeSubmitThread = new Thread(new IndexExeSubmitThread(canalTool, dataSourceManager, solrIndexService,
                solrCollNameMap, indexExe));
        indexExeSubmitThread.start();
    }

    public DataSourceManage getDataSourceManager() {
        return dataSourceManager;
    }

}

class CommitThread implements Runnable {
    SolrIndexService solrIndexService;
    String collNames = "";

    public CommitThread(SolrIndexService solrIndexService, String collNames) {
        super();
        this.solrIndexService = solrIndexService;
        this.collNames = collNames;
    }

    @Override
    public void run() {
        while (true) {
            long bt = System.currentTimeMillis();
            solrIndexService.commit(collNames);
            // solrIndexService.commit("trade");
            // solrIndexService.commit("member");
            // solrIndexService.commit("comment");
            // solrIndexService.commit("brand");
            // System.out.println("Commit [" + collNames + "]:" +
            // (System.currentTimeMillis() - bt));
            try {
                TimeUnit.SECONDS.sleep(5);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}

class IndexExeSubmitThread implements Runnable {
    CanalTool canalTool;
    DataSourceManage dataSourceManager;
    SolrIndexService solrIndexService;
    Map<String, String> solrCollNameMap;
    ExecutorService indexExe;

    public IndexExeSubmitThread(CanalTool canalTool, DataSourceManage dataSourceManager, SolrIndexService solrIndexService,
            Map<String, String> solrCollNameMap, ExecutorService indexExe) {
        super();
        this.canalTool = canalTool;
        this.dataSourceManager = dataSourceManager;
        this.solrCollNameMap = solrCollNameMap;
        this.solrIndexService = solrIndexService;
        this.indexExe = indexExe;
    }

    @Override
    public void run() {
        while (true) {
            CanalMessage message = canalTool.getData();
            // String collName =
            // dataSourceManager.getCollNameByCanalFilter(message.getCanalFilterName());
            // SolrInputDocument doc =
            // dataSourceManager.getDataSourceHandler(collName).getData(Long.parseLong(message.getId()));
            // List<SolrInputDocument> docs = new ArrayList<>();
            // docs.add(doc);
            // solrIndexService.addDocument(collName, docs);
            // solrIndexService.commit(collName);
            // 多线程
            String collName = solrCollNameMap.get(message.getCanalFilterName());
            indexExe.submit(new IndexTask(dataSourceManager, message, solrIndexService, collName));
        }
    }

}

/**
 * Description: TODO 单次更新任务<br/>
 * 
 * @author: zhaoyun
 * @date: 2015年10月10日 下午4:13:32
 * @version: 1.0
 * @since: JDK 1.7
 */
class IndexTask implements Runnable {
    DataSourceManage dataSourceManager;
    CanalMessage message;
    SolrIndexService solrIndexService;
    String collName = "";

    public IndexTask(DataSourceManage dataSourceManager, CanalMessage message, SolrIndexService solrIndexService, String collName) {
        super();
        this.dataSourceManager = dataSourceManager;
        this.message = message;
        this.solrIndexService = solrIndexService;
        this.collName = collName;
    }

    @Override
    public void run() {
        SolrInputDocument doc = dataSourceManager.getDataSourceHandler(collName).getData(Long.parseLong(message.getId()));
        System.out.println("message:" + message.toString() + " ;doc:" + doc.toString());
        List<SolrInputDocument> docs = new ArrayList<>();
        if (!doc.isEmpty()) {// 判断是否为空doc
            docs.add(doc);
            solrIndexService.addDocument(collName, docs);
			//这里也可以处理自己的业务
        }
    }

}
