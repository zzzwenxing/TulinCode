package cn.com.search.dao;

import cn.com.search.core.Mapper;
import cn.com.search.model.GoodItem;

public interface GoodItemMapper extends Mapper<GoodItem> {
}