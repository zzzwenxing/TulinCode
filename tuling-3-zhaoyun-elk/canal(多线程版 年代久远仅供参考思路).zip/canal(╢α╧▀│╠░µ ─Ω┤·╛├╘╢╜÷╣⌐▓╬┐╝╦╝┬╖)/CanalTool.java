package com.cccc.searchcenter.manager.canal;

import java.net.InetSocketAddress;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.alibaba.otter.canal.client.CanalConnector;
import com.alibaba.otter.canal.client.CanalConnectors;
import com.alibaba.otter.canal.protocol.CanalEntry.Column;
import com.alibaba.otter.canal.protocol.CanalEntry.Entry;
import com.alibaba.otter.canal.protocol.CanalEntry.EntryType;
import com.alibaba.otter.canal.protocol.CanalEntry.EventType;
import com.alibaba.otter.canal.protocol.CanalEntry.RowChange;
import com.alibaba.otter.canal.protocol.CanalEntry.RowData;
import com.alibaba.otter.canal.protocol.Message;

/**
 * Description: TODO <br/>

 * @author: zhaoyun
 * @date: 2015年5月5日 下午5:35:09
 * @version: 1.0
 * @since: JDK 1.7
 */
@Service
public class CanalTool {
    private static final Logger logger = LoggerFactory.getLogger(CanalTool.class);
    @Value("${canal.server.url}")
    private String canalServer;
    @Value("${canal.server.port}")
    private int canalServerPort;
    // 缓存
    private static BlockingQueue<CanalMessage> house = new ArrayBlockingQueue<>(1000);
    // 特殊处理
    private Map<String, String> tableIdNameMap = new HashMap<>();

    /**
     * 多个canal instance多次调用load
     * 
     * @param instance
     * @param filter
     */
    public void load(String instance, String filter) {
        Thread canalInstanceLoadThread = new Thread(new CanalInstanceLoadThread(canalServer, canalServerPort, instance, filter,
                tableIdNameMap, house));
        canalInstanceLoadThread.start();
        logger.info("canal启动[" + instance + ";filter:" + filter + "]");
    }

    /**
     * 从缓存中拿数据
     * 
     * @return
     */
    public CanalMessage getData() {
        CanalMessage one = null;
        try {
            one = house.take();
            logger.info("take:" + one.toString() + ";houseSize:" + house.size());
        } catch (InterruptedException e) {
            logger.error("从canal-house中取数据异常", e);
        }
        return one;
    }

    /**
     * 设置缓存数据
     * 
     */
    public void setData(CanalMessage canalMessage) {
        try {
            house.put(canalMessage);
            logger.info("put:" + canalMessage.toString() + ";houseSize:" + house.size());
        } catch (InterruptedException e) {
            logger.error("从canal-house添加数据异常", e);
        }
    }

    public void setTableIdNameMap(Map<String, String> tableIdNameMap) {
        this.tableIdNameMap = tableIdNameMap;
    }

}

/**
 * 
 * Description: TODO 每个canalInstance开一个线程取数据，取到的数据都放到缓存中。<br/>
 * 
 * @author: zhaoyun
 * @date: 2015年5月22日 下午2:49:15
 * @version: 1.0
 * @since: JDK 1.7
 */
class CanalInstanceLoadThread implements Runnable {
    private static final Logger logger = LoggerFactory.getLogger(CanalInstanceLoadThread.class);
    String canalServer;
    int canalServerPort;
    String instance;
    String filter;
    BlockingQueue<CanalMessage> house;
    int batchSize = 1000;
    Map<String, String> tableIdNameMap;

    public CanalInstanceLoadThread(String canalServer, int canalServerPort, String instance, String filter,
            Map<String, String> tableIdNameMap, BlockingQueue<CanalMessage> house) {
        super();
        this.canalServer = canalServer;
        this.canalServerPort = canalServerPort;
        this.instance = instance;
        this.filter = filter;
        this.tableIdNameMap = tableIdNameMap;
        this.house = house;
    }

    @Override
    public void run() {
        // 创建链接
        CanalConnector connector = CanalConnectors.newSingleConnector(new InetSocketAddress(canalServer, canalServerPort),
                instance, "", "");
        long batchId = 0;
        try {
            connector.connect();
            connector.subscribe(filter);
            connector.rollback();
            while (true) {
                Message message = connector.getWithoutAck(batchSize); // 获取指定数量的数据
                batchId = message.getId();
                int size = message.getEntries().size();
                if (batchId == -1 || size == 0) {
                    try {
                        Thread.sleep(1000);
                    } catch (InterruptedException e) {
                    }
                } else {
                    List<CanalMessage> messages = parserMessage(message.getEntries());
                    for (CanalMessage one : messages) {
                        house.put(one);
                        logger.info("put:" + one.toString() + ";houseSize:" + house.size());
                    }
                }
                connector.ack(batchId); // 提交确认
            }
        } catch (Exception e) {
            logger.error("创建Canal异常", e);
            // if (batchId != 0)
            // connector.rollback(batchId); // 处理失败, 回滚数据
        } finally {
            connector.disconnect();
        }

    }

    /**
     * canal消息解析
     * 
     * @param entrys
     * @return
     */
    private List<CanalMessage> parserMessage(List<Entry> entrys) {
        List<CanalMessage> messageList = new ArrayList<>();
        for (Entry entry : entrys) {
            CanalMessage message = new CanalMessage();
            if (entry.getEntryType() == EntryType.TRANSACTIONBEGIN || entry.getEntryType() == EntryType.TRANSACTIONEND) {
                continue;
            }
            message.setSchameName(entry.getHeader().getSchemaName());
            message.setTableName(entry.getHeader().getTableName());
            RowChange rowChage = null;
            try {
                rowChage = RowChange.parseFrom(entry.getStoreValue());
            } catch (Exception e) {
                throw new RuntimeException("ERROR ## parser of eromanga-event has an error , data:" + entry.toString(), e);
            }

            EventType eventType = rowChage.getEventType();
            message.setEventType(eventType);
            for (RowData rowData : rowChage.getRowDatasList()) {
                if (eventType == EventType.DELETE) {
                    message.setId(getId(message.getSchameName(), message.getTableName(), rowData.getBeforeColumnsList()));
                } else if (eventType == EventType.INSERT) {
                    message.setId(getId(message.getSchameName(), message.getTableName(), rowData.getAfterColumnsList()));
                } else {
                    message.setId(getId(message.getSchameName(), message.getTableName(), rowData.getAfterColumnsList()));
                }
            }
            messageList.add(message);
        }
        return messageList;
    }

    private String getId(String dbName, String tableName, List<Column> columns) {
        String id = "";
        String keyFiledName = this.tableIdNameMap.get(dbName + "&" + tableName);
        if (StringUtils.isBlank(keyFiledName))
            keyFiledName = "id";
        for (Column column : columns) {
            if (column.getName().equals(keyFiledName)) {
                id = column.getValue();
                break;
            }
        }
        return id;
    }

}